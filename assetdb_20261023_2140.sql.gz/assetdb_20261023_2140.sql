/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.23-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: assetdb
-- ------------------------------------------------------
-- Server version	11.4.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `assetdb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `assetdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `assetdb`;

--
-- Table structure for table `asset_change_requests`
--

DROP TABLE IF EXISTS `asset_change_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_change_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_type` varchar(20) NOT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `requester_id` int(11) NOT NULL,
  `requested_data` text NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `reject_reason` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`),
  KEY `requester_id` (`requester_id`),
  CONSTRAINT `asset_change_requests_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asset_change_requests_ibfk_2` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_change_requests`
--

LOCK TABLES `asset_change_requests` WRITE;
/*!40000 ALTER TABLE `asset_change_requests` DISABLE KEYS */;
INSERT INTO `asset_change_requests` VALUES (3,'register',8,2,'{\"asset_name\":\"책상\",\"category_name\":\"가구\",\"serial_number\":\"\",\"item_code\":\"ITM-302774\",\"purchase_date\":\"2026-06-03\",\"purchase_price\":null,\"purchase_source\":null,\"receipt_image_url\":null,\"useful_life_years\":5,\"is_consumable\":0,\"stock_quantity\":0,\"location\":\"사무실\",\"dept_name\":\"관리부\",\"manager_name\":\"자산담당자(관리부)\",\"manager_contact\":\"010-2222-3333\",\"image_url\":null,\"description\":\"\"}','approved',NULL,'2026-06-03 09:01:42','2026-06-03 09:06:46'),(11,'modify',8,2,'{\"asset_name\":\"책상\",\"category_name\":\"가구\",\"serial_number\":\"\",\"item_code\":\"ITM-302774\",\"purchase_date\":\"2026-06-03\",\"purchase_price\":null,\"purchase_source\":\"\",\"receipt_image_url\":null,\"useful_life_years\":5,\"is_consumable\":0,\"stock_quantity\":0,\"location\":\"사무실\",\"dept_name\":\"관리부\",\"manager_name\":\"자산담당자(관리부)\",\"manager_contact\":\"010-2222-3333\",\"image_url\":\"/uploads/assets/1780668229522-750944195.jpg\",\"description\":\"\",\"status\":\"available\"}','approved',NULL,'2026-06-05 14:03:49','2026-06-05 14:07:53'),(12,'register',10,2,'{\"asset_name\":\"전구\",\"category_name\":\"방송 장비\",\"serial_number\":\"\",\"item_code\":\"ITM-035970\",\"purchase_date\":\"2026-06-06\",\"purchase_price\":10000,\"purchase_source\":null,\"receipt_image_url\":null,\"useful_life_years\":1,\"is_consumable\":0,\"stock_quantity\":0,\"location\":\"사무실\",\"dept_name\":\"관리부\",\"manager_name\":\"자산담당자(관리부)\",\"manager_contact\":\"010-2222-3333\",\"image_url\":\"/uploads/assets/1780710035935-659508316.jpg\",\"description\":\"\"}','approved',NULL,'2026-06-06 01:40:35','2026-06-26 07:31:41'),(14,'register',11,2,'{\"asset_name\":\"컴퓨터\",\"category_name\":\"방송 장비\",\"serial_number\":\"Asdfjw\",\"item_code\":\"M250\",\"purchase_date\":\"2026-06-01\",\"purchase_price\":1000000,\"purchase_source\":null,\"receipt_image_url\":null,\"useful_life_years\":5,\"is_consumable\":0,\"stock_quantity\":0,\"location\":\"방송실\",\"dept_name\":\"재정부\",\"manager_name\":\"자산담당자(관리부)\",\"manager_contact\":\"010-2222-3333\",\"image_url\":\"/uploads/assets/1783860787124-480294160.jpg\",\"manufacturer\":\"삼성전자\",\"description\":\"\"}','approved',NULL,'2026-07-12 12:53:07','2026-07-12 13:09:16');
/*!40000 ALTER TABLE `asset_change_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_history`
--

DROP TABLE IF EXISTS `asset_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `action_type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `action_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`),
  CONSTRAINT `asset_history_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_history`
--

LOCK TABLES `asset_history` WRITE;
/*!40000 ALTER TABLE `asset_history` DISABLE KEYS */;
INSERT INTO `asset_history` VALUES (4,8,1,'재정부장(관리자)','created','재정부장 승인에 의한 자산 신규 등록 완료','2026-06-03 09:06:46'),(11,8,1,'재정부장(관리자)','repaired','A/S 정비 기록 등록: repair (2026-06-05) - 비용: 10000원','2026-06-05 13:58:57'),(12,8,1,'재정부장(관리자)','updated','재정부장 승인에 의한 자산 정보 변경 완료','2026-06-05 14:07:53'),(13,8,1,'재정부장(관리자)','updated','자산 정보가 최고 관리자에 의해 직접 수정되었습니다.','2026-06-06 01:30:13'),(14,8,2,'자산담당자(관리부)','repaired','A/S 정비 기록 등록: repair (2026-06-06) - 비용: 50000원','2026-06-06 01:37:39'),(15,8,2,'자산담당자(관리부)','repaired','A/S 정비 기록 등록: inspection (2026-06-06) - 비용: 0원','2026-06-06 01:38:57'),(16,8,2,'자산담당자(관리부)','status_changed','자산 상태 변경: available ➔ under_maintenance','2026-06-26 07:30:46'),(17,10,1,'재정부장(관리자)','created','재정부장 승인에 의한 자산 신규 등록 완료','2026-06-26 07:31:41'),(18,11,1,'재정부장(관리자)','created','재정부장 승인에 의한 자산 신규 등록 완료','2026-07-12 13:09:16');
/*!40000 ALTER TABLE `asset_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_maintenance`
--

DROP TABLE IF EXISTS `asset_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_maintenance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `maintenance_date` date NOT NULL,
  `maintenance_type` varchar(50) DEFAULT 'repair',
  `cost` decimal(12,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `handler_name` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`),
  CONSTRAINT `asset_maintenance_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_maintenance`
--

LOCK TABLES `asset_maintenance` WRITE;
/*!40000 ALTER TABLE `asset_maintenance` DISABLE KEYS */;
INSERT INTO `asset_maintenance` VALUES (1,8,'2026-06-05','repair',10000.00,'가죽 교체','성원가구점','2026-06-05 13:58:57'),(2,8,'2026-06-06','repair',50000.00,'다리 수리',NULL,'2026-06-06 01:37:39'),(3,8,'2026-06-06','inspection',0.00,'점검',NULL,'2026-06-06 01:38:57');
/*!40000 ALTER TABLE `asset_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_name` varchar(100) NOT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'available',
  `serial_number` varchar(100) DEFAULT NULL,
  `item_code` varchar(100) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(12,2) DEFAULT NULL,
  `purchase_source` varchar(150) DEFAULT NULL,
  `receipt_image_url` varchar(255) DEFAULT NULL,
  `useful_life_years` int(11) DEFAULT 5,
  `is_consumable` tinyint(1) DEFAULT 0,
  `stock_quantity` int(11) DEFAULT 0,
  `location` varchar(150) DEFAULT NULL,
  `dept_name` varchar(100) DEFAULT NULL,
  `manager_name` varchar(100) DEFAULT NULL,
  `manager_contact` varchar(50) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `manufacturer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `serial_number` (`serial_number`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `dept_name` (`dept_name`),
  KEY `category_name` (`category_name`),
  KEY `location` (`location`),
  CONSTRAINT `assets_ibfk_1` FOREIGN KEY (`dept_name`) REFERENCES `departments` (`dept_name`) ON DELETE SET NULL,
  CONSTRAINT `assets_ibfk_2` FOREIGN KEY (`category_name`) REFERENCES `categories` (`category_name`) ON DELETE SET NULL,
  CONSTRAINT `assets_ibfk_3` FOREIGN KEY (`location`) REFERENCES `locations` (`location_name`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (1,'SHURE SM58 Dynamic Mic','방송 장비','available','SN-SHURE-SM58-01','ITM-2026-0001','2026-01-10',150000.00,'낙원상가 음향사',NULL,5,0,0,'방송실','관리부','자산담당자(관리부)','010-2222-3333',NULL,'예배용 다이나믹 마이크 SHURE SM58 1호기','2026-06-03 08:24:08','2026-06-03 08:24:08',NULL),(2,'Yamaha P-125 Digital Piano','악기','available','SN-YAMAHA-P125-02','ITM-2026-0002','2026-02-15',850000.00,'야마하 직영점',NULL,7,0,0,'본당 1층','관리부','자산담당자(관리부)','010-2222-3333',NULL,'본당 반주용 디지털 피아노','2026-06-03 08:24:08','2026-06-03 08:24:08',NULL),(3,'Premium Walnut Desk','가구','available','SN-DESK-WALNUT-03','ITM-2026-0003','2026-03-01',500000.00,'한샘가구',NULL,10,0,0,'사무실','재정부','재정부장(관리자)','010-1234-5678',NULL,'사무실 재정부 데스크','2026-06-03 08:24:08','2026-06-03 08:24:08',NULL),(4,'iMac 24\" M3 (Pink)','전자기기','available','SN-IMAC24-M3-04','ITM-2026-0004','2026-01-20',1850000.00,'애플 스토어',NULL,4,0,0,'자막실','관리부','자산담당자(관리부)','010-2222-3333',NULL,'자막 작업용 아이맥 M3 8GB 256GB','2026-06-03 08:24:08','2026-06-03 08:24:08',NULL),(8,'책상','가구','under_maintenance','','ITM-302774','2026-06-03',NULL,'',NULL,1,0,0,'사무실','관리부','자산담당자(관리부)','010-2222-3333','/uploads/assets/1780668229522-750944195.jpg','','2026-06-03 09:06:46','2026-06-26 07:30:46',NULL),(10,'전구','방송 장비','available',NULL,'ITM-035970','2026-06-06',10000.00,NULL,NULL,1,0,0,'사무실','관리부','자산담당자(관리부)','010-2222-3333','/uploads/assets/1780710035935-659508316.jpg',NULL,'2026-06-26 07:31:41','2026-06-26 07:31:41',NULL),(11,'컴퓨터','방송 장비','available','Asdfjw','M250','2026-06-01',1000000.00,NULL,NULL,5,0,0,'방송실','재정부','자산담당자(관리부)','010-2222-3333','/uploads/assets/1783860787124-480294160.jpg','','2026-07-12 12:53:07','2026-07-12 13:09:16','삼성전자');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'방송 장비','카메라, 마이크, 믹서 등'),(2,'악기','피아노, 신디사이저, 드럼 등'),(3,'가구','책상, 의자, 강대상 등'),(4,'전자기기','PC, 노트북, 태블릿 등'),(5,'차량','교회 승합차, 버스 등'),(6,'서적','도서 및 성경책 등');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(100) NOT NULL,
  `parent_dept_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `dept_name` (`dept_name`),
  KEY `parent_dept_id` (`parent_dept_id`),
  CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`parent_dept_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'교회',NULL,'2026-06-03 08:24:08'),(2,'재정부',1,'2026-06-03 08:24:08'),(3,'관리부',1,'2026-06-03 08:24:08'),(4,'미디어팀',1,'2026-06-03 08:24:08'),(5,'청년부',1,'2026-06-03 08:24:08');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `location_name` (`location_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'본당 1층','본당 예배실'),(2,'자막실','2층 자막실'),(3,'방송실','3층 방송 조정실'),(4,'새가족실','1층 새가족실'),(5,'사무실','사무행정 구역');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'관리자'),(2,'사용자'),(3,'자산담당');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1),(1,2),(2,2),(3,2),(4,2),(5,2),(2,3);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT 0,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `dept_name` varchar(100) DEFAULT NULL,
  `kakao_id` varchar(50) DEFAULT NULL,
  `must_change_password` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `kakao_id` (`kakao_id`),
  KEY `dept_name` (`dept_name`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`dept_name`) REFERENCES `departments` (`dept_name`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2b$10$mtGYBj0377PQdUhsKy.SeukNJw6/j4fkr9dEPYXRhFxyOc7hhRpXu',1,'재정부장(관리자)','admin@church.org','010-1234-5678','재정부',NULL,0,'2026-06-03 08:24:08','2026-06-03 08:37:40'),(2,'manager','$2b$10$nYZk39JrA2vvP4wFKWGOzuXYWSVMcv2ag5v.zTXg/wJ5ObHuJk0Z6',1,'자산담당자(관리부)','manager@church.org','010-2222-3333','관리부',NULL,0,'2026-06-03 08:24:08','2026-06-03 08:37:54'),(3,'user01','$2b$10$PBOBmhkgKW0QtI7PZ6ns.u4xVGNrFSJLiIN3ugMbmwU20t.QnGJcm',1,'김철수','chulsoo@example.com','010-9876-5432','청년부',NULL,0,'2026-06-03 08:24:08','2026-06-03 08:36:21'),(4,'user02','$2b$10$ex4X5f8RJ.y5B0fpXYngv.Cd/DhecMIhgdCLTmU6if01Jb9Fux/PG',1,'홍길동','gildong@example.com','010-5555-5555','미디어팀',NULL,0,'2026-06-03 08:24:08','2026-06-03 08:35:37'),(5,'nodamelove','$2b$10$l0o1nIFadScf0FUXvAkwKOKIp1BGxagRVjnVs7tMMVcP0Ko0PTVSm',0,'김무현','alicelove1112@gmail.com','010-9523-9225','교회',NULL,0,'2026-08-09 00:04:12','2026-08-09 00:04:12');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'assetdb'
--

--
-- Dumping routines for database 'assetdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-23 21:41:00
