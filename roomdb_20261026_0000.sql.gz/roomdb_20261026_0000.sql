/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.23-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: roomdb
-- ------------------------------------------------------
-- Server version	11.4.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `roomdb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `roomdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;

USE `roomdb`;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(100) NOT NULL,
  `parent_dept_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `dept_name` (`dept_name`),
  KEY `parent_dept_id` (`parent_dept_id`),
  CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`parent_dept_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'교회',NULL,'2025-09-06 07:35:33'),(2,'음악부',1,'2025-09-06 07:35:34'),(3,'교육국',1,'2025-09-06 07:35:34'),(4,'재정부',1,'2025-09-06 07:35:34'),(5,'원천엔젤스',2,'2025-09-06 07:35:38'),(6,'할렐루야찬양대',2,'2025-09-06 07:35:38'),(7,'임마누엘찬양대',2,'2025-09-06 07:35:38'),(8,'샬롬찬양대',2,'2025-09-06 07:35:38'),(9,'청년부',3,'2025-09-06 07:35:41'),(10,'청소년부',3,'2025-10-02 11:56:37'),(11,'실내악단',2,'2025-10-04 02:43:00'),(12,'관리부',1,'2025-12-25 11:38:28'),(14,'방송부',41,'2026-01-10 11:24:29'),(15,'원천문화공연단',1,'2026-01-10 11:30:53'),(16,'영아부',3,'2026-01-10 11:42:29'),(17,'유치부',3,'2026-01-10 11:43:51'),(18,'초등부',3,'2026-01-10 11:53:53'),(19,'유년부',3,'2026-01-10 11:54:49'),(20,'원천JEBS',3,'2026-01-10 12:13:41'),(21,'예배부',1,'2026-01-24 14:17:12'),(22,'성례부',1,'2026-01-24 14:17:56'),(23,'전도부',1,'2026-01-24 14:18:49'),(24,'새가족영접부',1,'2026-01-24 14:19:33'),(25,'봉사부',1,'2026-01-24 14:20:35'),(28,'회우부',1,'2026-01-24 14:22:45'),(29,'1대교구',51,'2026-01-24 14:23:57'),(30,'2대교구',51,'2026-01-24 14:24:14'),(31,'3대교구',51,'2026-01-24 14:24:23'),(32,'장학부',51,'2026-01-24 14:24:43'),(33,'구제부',51,'2026-01-24 14:25:07'),(34,'홍보부',1,'2026-01-24 14:25:53'),(35,'지역사회부',1,'2026-01-24 14:26:29'),(36,'평신도훈련원',1,'2026-01-24 14:28:01'),(37,'일대일제자양육반',36,'2026-01-24 14:28:28'),(38,'원천바이블아카데미',36,'2026-01-24 14:29:08'),(39,'샬롬경로대학',36,'2026-01-24 14:30:24'),(40,'원천선교회',1,'2026-01-24 14:31:12'),(41,'미디어센터',1,'2026-01-24 14:32:00'),(42,'원천사회복지단',1,'2026-01-24 14:32:50'),(43,'서울청소년효행봉사단',42,'2026-01-24 14:33:45'),(44,'청소년활동공간홍은누리',42,'2026-01-24 14:34:20'),(45,'연희안산데이케어센터',42,'2026-01-24 14:34:51'),(46,'사랑희망나눔센터',42,'2026-01-24 14:35:17'),(47,'도움상담센터',42,'2026-01-24 14:35:37'),(48,'1남전도회',1,'2026-01-24 14:36:15'),(49,'1여전도회',1,'2026-01-24 14:36:31'),(50,'총남전도회',1,'2026-01-24 14:36:55'),(51,'경조위원회',1,'2026-01-25 05:43:53'),(52,'원천아트미션',1,'2026-01-25 07:31:00'),(53,'언노운워십',2,'2026-01-25 07:40:17'),(54,'모세선교회',1,'2026-01-31 02:02:17');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation_inquiries`
--

DROP TABLE IF EXISTS `reservation_inquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation_inquiries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_id` int(11) NOT NULL,
  `inquirer_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `answer` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `reservation_id` (`reservation_id`),
  KEY `inquirer_id` (`inquirer_id`),
  CONSTRAINT `reservation_inquiries_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reservation_inquiries_ibfk_2` FOREIGN KEY (`inquirer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation_inquiries`
--

LOCK TABLES `reservation_inquiries` WRITE;
/*!40000 ALTER TABLE `reservation_inquiries` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation_inquiries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation_policies`
--

DROP TABLE IF EXISTS `reservation_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation_policies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `allow_same_day` tinyint(1) NOT NULL DEFAULT 0,
  `allow_monday` tinyint(1) NOT NULL DEFAULT 0,
  `allow_holidays` tinyint(1) NOT NULL DEFAULT 0,
  `start_time` time NOT NULL DEFAULT '09:00:00',
  `end_time` time NOT NULL DEFAULT '17:00:00',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `max_booking_months` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation_policies`
--

LOCK TABLES `reservation_policies` WRITE;
/*!40000 ALTER TABLE `reservation_policies` DISABLE KEYS */;
INSERT INTO `reservation_policies` VALUES (1,0,0,1,'09:00:00','17:00:00','2026-05-30 11:07:38','2026-10-23 01:42:11',1);
/*!40000 ALTER TABLE `reservation_policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `requester_id` int(11) DEFAULT NULL,
  `requester_name` varchar(100) NOT NULL,
  `requester_phone` varchar(50) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `reservation_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `is_recurring` tinyint(1) DEFAULT 0,
  `recurrence_rule` varchar(100) DEFAULT NULL,
  `parent_reservation_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `recurring_type` varchar(20) DEFAULT NULL,
  `recurring_end_date` date DEFAULT NULL,
  `reject_reason` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `room_id` (`room_id`),
  KEY `requester_id` (`requester_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES (50,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-05-03','14:30:00','16:30:00','엔젤스 연습','approved',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-02 12:42:35','weekly','2026-06-28',NULL),(51,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-05-10','14:30:00','16:30:00','엔젤스 연습','approved',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-02 12:42:35','weekly','2026-06-28',NULL),(52,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-05-17','14:30:00','16:30:00','엔젤스 연습','approved',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-02 12:42:35','weekly','2026-06-28',NULL),(53,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-05-24','14:30:00','16:30:00','엔젤스 연습','approved',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-02 12:42:35','weekly','2026-06-28',NULL),(54,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-05-31','14:30:00','16:30:00','엔젤스 연습','cancelled',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-26 06:10:37','weekly','2026-06-28',NULL),(55,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-06-07','14:30:00','16:30:00','엔젤스 연습','cancelled',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-26 06:10:41','weekly','2026-06-28',NULL),(56,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-06-14','14:30:00','16:30:00','엔젤스 연습','cancelled',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-26 06:10:46','weekly','2026-06-28',NULL),(57,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-06-21','14:30:00','16:30:00','엔젤스 연습','cancelled',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-26 06:10:49','weekly','2026-06-28',NULL),(58,12,13,'홍길동','010-2307-0437','원천엔젤스 연습','2026-06-28','14:30:00','16:30:00','엔젤스 연습','cancelled',1,NULL,NULL,'2026-05-02 12:23:04','2026-05-26 06:10:51','weekly','2026-06-28',NULL),(59,14,13,'홍길동','010-2307-0437','찬양팀 연습','2026-05-03','12:00:00','13:00:00','','approved',0,NULL,NULL,'2026-05-02 12:48:17','2026-05-02 13:08:04',NULL,NULL,NULL),(60,14,13,'홍길동','010-2307-0437','행사 리뷰','2026-05-05','12:00:00','15:00:00','','approved',0,NULL,NULL,'2026-05-02 13:17:28','2026-05-02 13:18:35',NULL,NULL,NULL),(61,14,13,'홍길동','010-7646-4920','행사 준비','2026-05-10','13:00:00','14:00:00','','approved',0,NULL,NULL,'2026-05-02 13:21:57','2026-05-02 13:25:40',NULL,NULL,NULL),(62,11,13,'홍길동','010-7646-4920','기도모임','2026-05-02','09:00:00','10:00:00','기도회','approved',0,NULL,NULL,'2026-05-02 13:33:29','2026-05-02 13:35:00',NULL,NULL,NULL),(63,12,12,'관리자','010-2307-0437','기도모임','2026-05-09','09:00:00','10:00:00','기도모임','approved',0,NULL,NULL,'2026-05-03 22:57:49','2026-05-03 23:06:24',NULL,NULL,NULL),(64,11,13,'홍길동','010-7646-4920','가족주일 행사 준비','2026-05-05','12:00:00','14:00:00','가족주일 행사 준비로 모입니다.','approved',0,NULL,NULL,'2026-05-04 07:47:55','2026-05-04 07:49:10',NULL,NULL,NULL),(65,13,13,'홍길동','010-2307-0437','엔젤스 기도회','2026-05-10','15:30:00','16:30:00','','approved',1,NULL,NULL,'2026-05-04 07:54:37','2026-05-04 07:55:10','monthly','2026-08-23',NULL),(66,13,13,'홍길동','010-2307-0437','엔젤스 기도회','2026-06-10','15:30:00','16:30:00','','cancelled',1,NULL,NULL,'2026-05-04 07:54:37','2026-05-26 06:10:31','monthly','2026-08-23',NULL),(67,13,13,'홍길동','010-2307-0437','엔젤스 기도회','2026-07-10','15:30:00','16:30:00','','cancelled',1,NULL,NULL,'2026-05-04 07:54:37','2026-05-26 06:10:34','monthly','2026-08-23',NULL),(68,13,13,'홍길동','010-2307-0437','엔젤스 기도회','2026-08-10','15:30:00','16:30:00','','cancelled',1,NULL,NULL,'2026-05-04 07:54:37','2026-05-04 22:10:46','monthly','2026-08-23',NULL),(69,11,13,'홍길동','010-2307-0437','바룩연습','2026-05-17','15:00:00','17:00:00','정기연습','approved',0,NULL,NULL,'2026-05-05 12:04:49','2026-05-05 12:05:04',NULL,NULL,NULL),(70,14,13,'홍길동','010-2307-0437','기도모임','2026-05-17','12:00:00','13:00:00','','approved',0,NULL,NULL,'2026-05-05 12:06:35','2026-05-05 12:06:49',NULL,NULL,NULL),(71,12,13,'홍길동','010-2307-0437','교사모임','2026-05-24','12:00:00','13:00:00','월례회','approved',1,NULL,NULL,'2026-05-10 01:56:05','2026-05-10 01:56:22','monthly','2026-05-24',NULL),(72,13,13,'홍길동','010-2307-0437','교사모임','2026-05-24','09:00:00','10:00:00','','approved',0,NULL,NULL,'2026-05-10 11:58:00','2026-05-15 09:21:14',NULL,NULL,NULL),(73,12,13,'홍길동','010-2307-0437','새가족 초대 행사준비','2026-05-18','14:00:00','15:00:00','','rejected',0,NULL,NULL,'2026-05-15 09:20:53','2026-05-26 06:04:07',NULL,NULL,NULL),(74,14,15,'김무현','010-9523-9225','','2026-05-30','10:00:00','14:00:00','','cancelled',0,NULL,NULL,'2026-05-26 05:48:50','2026-05-26 06:14:29',NULL,NULL,NULL),(75,13,13,'홍길동','010-2307-0437','모임','2026-05-30','09:00:00','10:00:00','부서','rejected',0,NULL,NULL,'2026-05-26 06:11:58','2026-05-26 06:13:02',NULL,NULL,'해당시간 불가'),(76,11,15,'김무현','010-9523-9225','청년','2026-05-30','09:00:00','10:00:00','','cancelled',0,NULL,NULL,'2026-05-26 06:14:14','2026-05-27 06:47:59',NULL,NULL,NULL),(77,11,15,'김무현','010-9523-9225','','2026-05-30','11:00:00','12:00:00','','cancelled',0,NULL,NULL,'2026-05-26 06:15:55','2026-05-27 06:47:56',NULL,NULL,NULL),(78,11,12,'관리자','010-9132-0546','예약','2026-05-18','09:00:00','10:00:00','','rejected',0,NULL,NULL,'2026-05-28 10:25:40','2026-05-28 10:26:37',NULL,NULL,'과거일자로 예약불가'),(79,14,13,'홍길동','010-2307-0437','초등부 찬양팀 연습','2026-06-20','13:00:00','14:00:00','초등부 찬양팀 연습','approved',1,NULL,NULL,'2026-06-14 02:27:41','2026-06-21 06:51:52','weekly','2026-07-14',NULL),(80,14,13,'홍길동','010-2307-0437','초등부 찬양팀 연습','2026-06-27','13:00:00','14:00:00','초등부 찬양팀 연습','approved',1,NULL,NULL,'2026-06-14 02:27:41','2026-06-21 06:51:52','weekly','2026-07-14',NULL),(81,14,13,'홍길동','010-2307-0437','초등부 찬양팀 연습','2026-07-04','13:00:00','14:00:00','초등부 찬양팀 연습','approved',1,NULL,NULL,'2026-06-14 02:27:41','2026-06-21 06:51:52','weekly','2026-07-14',NULL),(82,14,13,'홍길동','010-2307-0437','초등부 찬양팀 연습','2026-07-11','13:00:00','14:00:00','초등부 찬양팀 연습','approved',1,NULL,NULL,'2026-06-14 02:27:41','2026-06-21 06:51:52','weekly','2026-07-14',NULL),(83,11,12,'관리자','010-9132-0546','테스트 예약','2026-06-21','14:00:00','15:00:00','테스트','rejected',0,NULL,NULL,'2026-06-20 04:16:05','2026-06-21 06:52:06',NULL,NULL,NULL),(84,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-08-15','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:14:54','weekly','2026-12-26',NULL),(85,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-08-22','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:37','weekly','2026-12-26',NULL),(86,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-08-29','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:40','weekly','2026-12-26',NULL),(87,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-09-05','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:36','weekly','2026-12-26',NULL),(88,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-09-12','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:34','weekly','2026-12-26',NULL),(89,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-09-19','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:32','weekly','2026-12-26',NULL),(90,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-09-26','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:30','weekly','2026-12-26',NULL),(91,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-10-03','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:28','weekly','2026-12-26',NULL),(92,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-10-10','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:26','weekly','2026-12-26',NULL),(93,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-10-17','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:24','weekly','2026-12-26',NULL),(94,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-10-24','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:22','weekly','2026-12-26',NULL),(95,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-10-31','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:15','weekly','2026-12-26',NULL),(96,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-11-07','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:12','weekly','2026-12-26',NULL),(97,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-11-14','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:05','weekly','2026-12-26',NULL),(98,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-11-21','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:10','weekly','2026-12-26',NULL),(99,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-11-28','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:03','weekly','2026-12-26',NULL),(100,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-12-05','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:14:56','weekly','2026-12-26',NULL),(101,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-12-12','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:14:58','weekly','2026-12-26',NULL),(102,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-12-19','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:07','weekly','2026-12-26',NULL),(103,14,12,'관리자','010-9132-0546','초등부 찬양팀 연습','2026-12-26','12:00:00','14:00:00','연습','approved',1,NULL,NULL,'2026-08-12 02:14:02','2026-08-12 02:15:01','weekly','2026-12-26',NULL),(111,12,23,'배석인','010-2307-0437','원천엔젤스 ','2026-08-14','13:00:00','14:00:00','테스트','approved',0,NULL,NULL,'2026-08-13 08:58:29','2026-08-13 08:58:59',NULL,NULL,NULL),(112,12,15,'김무현','010-9523-9225','청소년부 헌신예배 준비모임','2026-08-14','15:30:00','16:30:00','','approved',0,NULL,NULL,'2026-08-14 00:31:55','2026-08-14 00:32:03',NULL,NULL,NULL),(113,11,23,'배석인','010-2307-0437','예약 테스트','2026-08-16','15:00:00','16:00:00','','cancelled',0,NULL,NULL,'2026-08-15 05:45:13','2026-08-15 05:57:37',NULL,NULL,NULL),(114,17,20,'유년부','010-2061-7214','유년부 성탄 연습','2026-10-18','13:00:00','17:00:00','유년부 성탄발표회 연습','cancelled',0,NULL,NULL,'2026-10-17 01:43:38','2026-10-17 03:59:40',NULL,NULL,NULL),(115,12,13,'홍길동','010-2307-0437','13기관모임','2026-10-25','09:00:00','10:00:00','','approved',0,NULL,NULL,'2026-10-23 01:32:06','2026-10-23 01:35:01',NULL,NULL,NULL),(116,12,13,'홍길동','010-2307-0437','청년','2026-10-24','09:00:00','10:00:00','','rejected',0,NULL,NULL,'2026-10-23 01:39:38','2026-10-23 01:47:48',NULL,NULL,NULL),(117,17,13,'Test','010-9523-9225','ㅇㅇ','2026-10-27','09:00:00','10:00:00','','approved',0,NULL,NULL,'2026-10-23 01:49:20','2026-10-23 01:49:28',NULL,NULL,NULL);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'관리자'),(2,'사용자');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_blocked_times`
--

DROP TABLE IF EXISTS `room_blocked_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_blocked_times` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `day_of_week` int(11) DEFAULT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `recurring_type` enum('weekly','monthly_date','monthly_nth') DEFAULT 'weekly',
  `day_of_month` int(11) DEFAULT NULL,
  `nth_week` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `room_id` (`room_id`),
  CONSTRAINT `room_blocked_times_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_blocked_times`
--

LOCK TABLES `room_blocked_times` WRITE;
/*!40000 ALTER TABLE `room_blocked_times` DISABLE KEYS */;
INSERT INTO `room_blocked_times` VALUES (4,11,0,'08:00:00','14:00:00','찬양대 연습','2026-05-02 12:21:45','weekly',1,1),(5,12,0,'13:30:00','15:30:00','원천엔젤스 정기연습','2026-08-13 08:57:07','weekly',1,1),(6,12,0,'11:00:00','13:00:00','청소년부 예배','2026-08-14 00:30:38','weekly',1,1);
/*!40000 ALTER TABLE `room_blocked_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_name` varchar(100) NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `floor` varchar(20) NOT NULL,
  `dept_name` varchar(100) DEFAULT NULL,
  `manager_name` varchar(100) DEFAULT NULL,
  `manager_contact` varchar(50) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `dept_name` (`dept_name`),
  CONSTRAINT `rooms_ibfk_1` FOREIGN KEY (`dept_name`) REFERENCES `departments` (`dept_name`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (11,'찬양대 연습실',50,'B3','교회',NULL,NULL,'/uploads/rooms/1781928346686-112878620.png','2026-04-18 13:20:42','2026-07-01 10:33:53'),(12,'멀티미디어실',50,'B3','교회','홍길동','010-3333-4444','/uploads/rooms/1780580805654-111829421.png','2026-04-18 13:21:01','2026-07-01 10:33:36'),(13,'유치부실',10,'B3','교회','유치부선생','010-9999-8888','/uploads/rooms/1780580827485-907645004.png','2026-04-18 13:21:24','2026-06-04 13:47:07'),(14,'가나홀',100,'1','교회','다니엘','010-2222-7777','/uploads/rooms/1780580845524-640102278.png','2026-04-18 13:21:43','2026-07-01 10:33:30'),(17,'벧엘성전',50,'B3','교회',NULL,NULL,'/uploads/rooms/1780580855147-313471399.png','2026-05-26 06:05:34','2026-07-01 10:33:43');
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (12,1),(15,1),(16,1),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT 0,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `dept_name` varchar(100) DEFAULT NULL,
  `kakao_id` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `password` varchar(255) DEFAULT NULL,
  `must_change_password` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `kakao_id` (`kakao_id`),
  KEY `dept_name` (`dept_name`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (12,'admin','$2b$10$OmHcR28P2W/nfhqlzOt9e.TM71a5R8iJEESLp9BsQXr7bm1o2iqlO',1,'관리자','','010-9132-0546','교회',NULL,'2026-05-02 09:32:07','2026-05-26 06:29:33',NULL,0),(13,'user01','$2b$10$d9gMyutA4G4tnvR76tr20el8KCo2oMaztNZQ7uTpD5A2nYUcEsmHO',1,'Test','','010-9523-9225','샬롬찬양대',NULL,'2026-05-02 09:33:52','2026-10-23 01:36:24',NULL,0),(14,'chinakim','$2b$10$WQAUHnz0WgTfh4lRXsA/bOBXVKHYolfAvAgWFK5e54/ORr4Z9MPx2',1,'김정현','chinakim@naver.com','010-9977-9969','원천문화공연단',NULL,'2026-05-22 10:08:59','2026-05-26 06:07:40',NULL,0),(15,'nodamelove','$2b$10$6nq208H5u/bNtqUpBQJcFOqKX6RjDYRWlsgg9vYjoNl6GuctCUxVC',1,'김무현','alicelove1112@gmail.com','010-9523-9225','교회',NULL,'2026-05-26 05:38:29','2026-08-28 06:58:31',NULL,0),(16,'youngca7','$2b$10$ow6enXlQJmLj82PweiKmyuRxyRrY9tqtYfIv6cFG6YV7GaWOi9rde',1,'정미영','youngca7@naver.com','010-9270-1082','교회',NULL,'2026-05-26 06:02:50','2026-10-23 01:23:44',NULL,0),(17,'chldbfl97','$2b$10$DnreCnU091VyJ6ViM/NH5.XfPivzhJZqsiMf2rFDGKaT6TmSXDPTO',1,'최유리','','010-5611-0674','원천문화공연단',NULL,'2026-05-30 05:26:24','2026-05-31 06:29:31',NULL,0),(18,'mjson11 ','$2b$10$4mHhRdDuxrovEWX0KDBbGeo5SJ5lReC/Zt4Cc65gjTKGJO6n.n5S6',1,'손명진','mjson11@naver.com','010-8997-6494','청소년활동공간홍은누리',NULL,'2026-05-30 10:47:25','2026-05-31 06:29:29',NULL,0),(19,'woncheon','$2b$10$GDvQgJegJapjyorde8FJTe8/AwKI5hPfhrNtp7hz9KX6gBrmfYhTu',1,'김혜린','woncheonchurch@gmail.com','010-2074-8446','방송부',NULL,'2026-06-13 03:49:36','2026-06-13 03:49:57',NULL,0),(20,'ynb0001','$2b$10$hTa8GqOV0h0q/PF29Q0YGexUvbe9jwn7/MZ1B5066pu46VRetY2u6',0,'유년부','','010-2061-7214','교육국',NULL,'2026-06-21 06:42:27','2026-10-17 01:42:34',NULL,0),(21,'초등부','$2b$10$yWeG1cawwfBT33upoV.O4OcCKOBt0KrAQiXRoCQBJeLmhcRL7qhB6',0,'초등부','','010-9239-3474','교육국',NULL,'2026-06-21 06:43:30','2026-08-26 02:41:25',NULL,0),(22,'youthministry ','$2b$10$H2AiDBchsHRNIyXLjL7wou/Ui8wMqlJv8rvBa7s6GlgWDNusmGnkq',0,'청소년부','','010-9523-9225','교육국',NULL,'2026-07-15 04:53:02','2026-10-23 02:01:35',NULL,1),(23,'angel001','$2b$10$jH2hOkJCNOn/c3egBbeU/e2SIX1J72ErLtIseqhxH0Lk.o0NOP/Za',0,'배석인','baeseokin@gmail.com','010-2307-0437','원천엔젤스',NULL,'2026-08-13 08:53:27','2026-08-15 05:31:08',NULL,0),(24,'keepho','$2b$10$WGXTnvZ2jXQuVf1ym7Lmc.CtRn5PFgoM5gI7pnfMch.66wGXwNNly',0,'조호연','','010-9971-2793','언노운워십',NULL,'2026-10-17 06:55:51','2026-10-17 06:55:51',NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'roomdb'
--

--
-- Dumping routines for database 'roomdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-26  0:00:06
